import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UploadImageService {

  constructor(
    private http: HttpClient
  ) { }

  uploadImage(endpoint: string, formData: FormData) {
    return this.http.post(endpoint, formData);
  }
}
