import {Component} from '@angular/core';
import {defineCustomElements} from '@ionic/pwa-elements/loader';
import {Platform} from '@ionic/angular';
import {SplashScreen} from '@capacitor/splash-screen';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(
    private platform: Platform
  ) {
    defineCustomElements(window);
  }

  initializeApp() {
    this.platform.ready().then(async () => {
      await SplashScreen.hide();
    });
  }
}
